#!/bin/sh
START=$(date +%s.%N)

echo Script $0
echo PID $$
echo Store file: $1

store=$1

idMD=N100E05

numThermo=1000
#---------0123  = 1E03

numCycles=100000
#---------012345 = 1E05 

fix1=10
fix2=100
fix3=1000
numDump=1000


echo LAMMPS NVE -- 100 CO2 molecules
echo Thermo ${numThermo}: Cycles ${numCycles}

mkdir ${store}
mkdir ${store}/lmp                                            # LAMMPS input file
mkdir ${store}/log																						# LAMMPS log file
mkdir ${store}/msd																						# Diffusion coefficient calculation via MSD in LAMMPS
mkdir ${store}/nve																						# Coordinates in XYZ format of nve-MD LAMMPS

paste -d ":" ./database/lx/lx0100 ./database/Temperature/tempK | while IFS=":" read -r lx temp; do ### -----------

echo ${temp} K

cat <<ENDFILE > ${store}/in.${temp}K100N.lmp
# LAMMPS script for nve Molecular Dynamics. CO2 ..................................................................
units           real																					# Angstroms, g/mol, etc.
dimension       3																							# Molecule + charge.
boundary        p p p																					# Periodic Boundaries conditions.
atom_style      full																					# Time step (default = 1.0fs for real units).

read_data       ./database/LMPDAT/N100/${temp}K100N.lmpdat  	# Atom definition
region					all block 0 ${lx} 0 ${lx} 0 ${lx}            	# Region box definition lx, ly, lz.
replicate       1 1 1																					# cell replication (none = 1 1 1).
include					./database/potential/TraPPECO2 								# (External file) CO2 potential TraPPECO2.

velocity       	all create ${temp} 4928459 rot yes mom yes dist uniform
reset_timestep 	0
fix            	ensemble all nvt temp ${temp} ${temp} 100 tchain 1

timestep       	2.0

compute         msd all msd com yes														# msd
fix             msd all ave/time ${fix1} ${fix2} ${fix3} c_msd[4] file msd${temp}K100N 
thermo_style		custom step temp c_msd[4]
dump           	dumpXYZ all xyz ${numDump} nve${temp}K100N.xyz			# (Output) store XYZ for MD.
thermo_style   	one
thermo         	${numThermo}																					
run             ${numCycles}																	# (Run the simulation) Total samples.
# END LAMMPS SCRIPT ...............................................................................................
ENDFILE

	#lmp < ${store}/in.${temp}K100N.lmp -log log.lammps -screen none	                                   # LAMMPS run
	/share/apps/lammps/bin/lmp_g++_openmpi -i  ${store}/in.${temp}K100N.lmp -log log.lammps -screen none

	mv log.lammps msd${temp}K100N nve${temp}K100N.xyz  ${store}
	mv ${store}/log.lammps 						${store}/${temp}K100N.log

	mv ${store}/in.${temp}K100N.lmp 	${store}/lmp
	mv ${store}/${temp}K100N.log 		  ${store}/log
	mv ${store}/msd${temp}K100N 			${store}/msd
	mv ${store}/nve${temp}K100N.xyz	  ${store}/nve

done ### ---------------------------------------------------------------------------------------------------------

tar -czf ${idMD}.tar.gz ${store}
ls  -lh  ${idMD}.tar.gz | cut -d" " -f5- 

END=$(date +%s.%N)
dt1=$(echo "$END - $START"   | bc)
dd1=$(echo "$dt1/86400"      | bc)
dt2=$(echo "$dt1-86400*$dd1" | bc)
dh1=$(echo "$dt2/3600"       | bc)
dt3=$(echo "$dt2-3600*$dh1"  | bc)
dm1=$(echo "$dt3/60"         | bc)
ds1=$(echo "$dt3-60*$dm1"    | bc)

LC_NUMERIC=C printf "Total runtime: %d:%02d:%02d:%02.2f\n" $dd1 $dh1 $dm1 $ds1
